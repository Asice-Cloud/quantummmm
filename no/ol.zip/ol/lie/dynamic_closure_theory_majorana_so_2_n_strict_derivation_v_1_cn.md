# Dynamic Closure Theory for Majorana Systems

# 基于 SO(2N) 的严格推导

---

# 一、Majorana Algebra

定义：

\[
\Gamma
=
(\gamma_1,\gamma_2,\dots,\gamma_{2N})^T
\tag{1}
\]

满足：

\[
\{\gamma_i,\gamma_j\}=2\delta_{ij}
\tag{2}
\]

以及：

\[
\gamma_i^\dagger=\gamma_i
\tag{3}
\]

---

# 二、一般 Quadratic Majorana Hamiltonian

最一般 quadratic Hamiltonian：

\[
\boxed{
H(t)
=
\frac i4
\Gamma^TA(t)\Gamma
}
\tag{4}
\]

其中：

\[
A(t)^T=-A(t)
\tag{5}
\]

因此：

\[
A(t)\in\mathfrak{so}(2N)
\tag{6}
\]

---

# 三、Heisenberg Equation

计算：

\[
\dot\gamma_i
=
i[H,\gamma_i]
\tag{7}
\]

代入：

\[
H
=
\frac i4
\sum_{jk}
A_{jk}\gamma_j\gamma_k
\tag{8}
\]

得到：

\[
\dot\gamma_i
=
-\frac14
\sum_{jk}
A_{jk}
[\gamma_j\gamma_k,\gamma_i]
\tag{9}
\]

利用 Clifford algebra：

\[
[\gamma_j\gamma_k,\gamma_i]
=
2(\delta_{ki}\gamma_j-\delta_{ji}\gamma_k)
\tag{10}
\]

于是：

\[
\dot\gamma_i
=
-\frac12
\sum_{jk}
A_{jk}
(\delta_{ki}\gamma_j-\delta_{ji}\gamma_k)
\tag{11}
\]

第一项：

\[
-\frac12
\sum_j
A_{ji}\gamma_j
\tag{12}
\]

第二项：

\[
+\frac12
\sum_k
A_{ik}\gamma_k
\tag{13}
\]

由于：

\[
A_{ji}=-A_{ij}
\tag{14}
\]

因此：

\[
\boxed{
\dot\gamma_i
=
\sum_jA_{ij}\gamma_j
}
\tag{15}
\]

写成矩阵形式：

\[
\boxed{
\dot\Gamma
=
A(t)\Gamma
}
\tag{16}
\]

---

# 四、SO(2N) Evolution

定义：

\[
\Gamma(t)=R(t)\Gamma(0)
\tag{17}
\]

则：

\[
\dot R=A(t)R
\tag{18}
\]

因此：

\[
\boxed{
R(T)
=
\mathcal P
\exp
\left(
\int_0^TA(t)dt
\right)
}
\tag{19}
\]

由于：

\[
A^T=-A
\tag{20}
\]

因此：

\[
\boxed{
R(T)\in SO(2N)
}
\tag{21}
\]

---

# 五、Static Closure Theory

设：

\[
A(t)
=
\sum_\mu a_\mu(t)X_\mu
\tag{22}
\]

其中：

\[
X_\mu\in\mathfrak{so}(2N)
\tag{23}
\]

旧 closure 定义：

\[
\boxed{
\mathfrak g_0
=
\mathrm{Lie}\{X_\mu\}
}
\tag{24}
\]

即：

\[
\mathfrak g_0
=
\mathrm{span}
\left(
X_\mu,
[X_\mu,X_\nu],
[X_\mu,[X_\nu,X_\rho]],
\dots
\right)
\tag{25}
\]

---

# 六、Moving Generator Structure

实际演化过程中：

Hamiltonian generator 本身也被 transport。

定义：

\[
\boxed{
X_\mu(t)
=
U(t)X_\mu U^{-1}(t)
}
\tag{26}
\]

即：

\[
X_\mu(t)
=
\mathrm{Ad}_{U(t)}X_\mu
\tag{27}
\]

因此：

真正 Hamiltonian：

\[
\boxed{
H(t)
=
\sum_\mu
 a_\mu(t)X_\mu(t)
}
\tag{28}
\]

---

# 七、Dynamic Closure

因此：

closure 不再是固定 Lie algebra。

真正 closure 定义为：

\[
\boxed{
\mathfrak g_{\mathrm{dyn}}
=
\mathrm{Lie}
\{
X_\mu(t)
\}_{t\in[0,T]}
}
\tag{29}
\]

---

# 八、Instantaneous Closure Bundle

定义每个时刻：

\[
\boxed{
\mathfrak g(t)
=
\mathrm{Lie}
\{X_\mu(t)\}
}
\tag{30}
\]

因此：

系统真正结构：

不是单个 Lie algebra。

而是：

\[
\boxed{
\{\mathfrak g(t)\}_{t\in[0,T]}
}
\tag{31}
\]

即：

Lie-algebra bundle。

---

# 九、Adjoint Transport

由于：

\[
X_\mu(t)
=
U(t)X_\mu U^{-1}(t)
\tag{32}
\]

因此：

\[
\boxed{
\mathfrak g(t)
=
\mathrm{Ad}_{U(t)}\mathfrak g(0)
}
\tag{33}
\]

---

# 十、Magnus Expansion

定义：

\[
R(T)=e^{\Omega(T)}
\tag{34}
\]

则：

\[
A_{\mathrm{eff}}
=
\frac1T\Omega(T)
\tag{35}
\]

---

# 十一、Magnus 一阶

\[
\boxed{
\Omega_1
=
\int_0^TA(t_1)dt_1
}
\tag{36}
\]

---

# 十二、Magnus 二阶

\[
\boxed{
\Omega_2
=
\frac12
\int_0^Tdt_1
\int_0^{t_1}dt_2
[A(t_1),A(t_2)]
}
\tag{37}
\]

---

# 十三、Magnus 三阶

\[
\boxed{
\Omega_3
=
\frac16
\int dt_1dt_2dt_3
(
[A_1,[A_2,A_3]]
+
[A_3,[A_2,A_1]]
)
}
\tag{38}
\]

其中：

\[
A_i=A(t_i)
\tag{39}
\]

---

# 十四、Dynamic Closure Growth

由于：

\[
A(t_i)\in\mathfrak g(t_i)
\tag{40}
\]

因此：

Magnus hierarchy：

会生成：

\[
[\mathfrak g(t_1),\mathfrak g(t_2)]
\tag{41}
\]

若：

\[
[\mathfrak g(t_1),\mathfrak g(t_2)]
\subseteq
\mathfrak g(t)
\tag{42}
\]

则：

closure stable。

若：

\[
[\mathfrak g(t_1),\mathfrak g(t_2)]
\not\subseteq
\mathfrak g(t)
\tag{43}
\]

则：

\[
\boxed{
\text{dynamic closure enlargement}
}
\tag{44}
\]

---

# 十五、Perturbation Theory

加入扰动：

\[
A(t)
=
A_0(t)+\epsilon B(t)
\tag{45}
\]

其中：

\[
B(t)\in\mathfrak{so}(2N)
\tag{46}
\]

---

旧 static criterion：

\[
[B,\mathfrak g_0]
\subseteq
\mathfrak g_0
\tag{47}
\]

已经不够。

---

真正 dynamic criterion：

\[
\boxed{
[B(t),\mathfrak g(t)]
\subseteq
\mathfrak g(t)
\quad
\forall t
}
\tag{48}
\]

若成立：

closure stable。

若不成立：

\[
\boxed{
\mathfrak g(t)
\to
\mathfrak g'(t)
}
\tag{49}
\]

即：

closure enlargement。

---

# 十六、Effective Hamiltonian

定义：

\[
R(T)
=
e^{A_{\mathrm{eff}}T}
\tag{50}
\]

因此：

\[
\boxed{
A_{\mathrm{eff}}
=
\frac1T
\log R(T)
}
\tag{51}
\]

对应 effective Hamiltonian：

\[
\boxed{
H_{\mathrm{eff}}
=
\frac i4
\Gamma^TA_{\mathrm{eff}}\Gamma
}
\tag{52}
\]

---



---

# 十九、最终统一结构

对于任意：

\[
2N
\]

个 Majorana：

---

## Hamiltonian

\[
H(t)
=
\frac i4
\Gamma^TA(t)\Gamma
\]

---

## Dynamics

\[
\dot\Gamma=A(t)\Gamma
\]

---

## Evolution

\[
R(T)
=
\mathcal P
\exp
\left(
\int_0^TA(t)dt
\right)
\in SO(2N)
\]

---

## Moving generators

\[
X_\mu(t)
=
U(t)X_\mu U^{-1}(t)
\]

---

## Dynamic closure

\[
\mathfrak g_{\mathrm{dyn}}
=
\mathrm{Lie}
\{X_\mu(t)\}
\]

---

## Magnus hierarchy

\[
\Omega(T)
=
\sum_n\Omega_n
\]

---

## Effective Hamiltonian

\[
A_{\mathrm{eff}}
=
\frac1T\log R(T)
\]

---

## Dynamic criterion

\[
[B(t),\mathfrak g(t)]
\subseteq
\mathfrak g(t)
\ ?
\]

决定：

closure 是否扩张。

---

# 二十、最终核心结构

Majorana dynamics 的真正本质：

不是固定 SU(2)。

不是 Bloch sphere。

不是 quaternion。

真正普适结构：

\[
\boxed{
\mathfrak g(t)
=
\mathrm{Ad}_{U(t)}\mathfrak g(0)
}
\]

以及：

\[
\boxed{
A_{\mathrm{eff}}
=
\frac1T
\log
\left(
\mathcal P
\exp
\left(
\int_0^TA(t)dt
\right)
\right)
}
\]

即：

SO(2N) 上的 dynamic Lie-closure transport theory。