# SO(2N) Majorana Effective Hamiltonian 与 Closure 理论

# 严格推导版

---

# 一、目标

本文从：

\[
2N
\]

个 Majorana 出发，

严格推导：

- quadratic Majorana Hamiltonian
- SO(2N) dynamics
- Magnus expansion
- effective Hamiltonian
- Lie closure
- perturbation-induced enlargement

并建立：

完整的 closure + effective Hamiltonian 理论框架。

---

# 二、Majorana Algebra

定义 Majorana operators：

\[
\gamma_i^\dagger=\gamma_i
\]

满足 Clifford algebra：

\[
\{\gamma_i,\gamma_j\}=2\delta_{ij}
\tag{1}
\]

定义 Majorana 向量：

\[
\Gamma
=
(\gamma_1,\gamma_2,\dots,\gamma_{2N})^T
\tag{2}
\]

---

# 三、一般 Quadratic Majorana Hamiltonian

最一般 quadratic Hamiltonian：

\[
\boxed{
H(t)
=
\frac i4
\Gamma^TA(t)\Gamma
}
\tag{3}
\]

其中：

\[
A(t)^T=-A(t)
\tag{4}
\]

因此：

\[
A(t)\in\mathfrak{so}(2N)
\]

即：

quadratic Majorana Hamiltonian 的 generator：

天然属于：

\[
\boxed{
\mathfrak{so}(2N)
}
\]

---

# 四、Heisenberg Equation

计算：

\[
\dot\gamma_i
=
i[H,\gamma_i]
\tag{5}
\]

代入：

\[
H
=
\frac i4
\sum_{jk}
A_{jk}\gamma_j\gamma_k
\]

得到：

\[
\dot\gamma_i
=
-\frac14
\sum_{jk}
A_{jk}
[\gamma_j\gamma_k,\gamma_i]
\tag{6}
\]

利用：

\[
[\gamma_j\gamma_k,\gamma_i]
=
2(\delta_{ki}\gamma_j-\delta_{ji}\gamma_k)
\tag{7}
\]

于是：

\[
\dot\gamma_i
=
-\frac12
\sum_{jk}
A_{jk}
(\delta_{ki}\gamma_j-\delta_{ji}\gamma_k)
\]

第一项：

\[
-\frac12
\sum_j
A_{ji}\gamma_j
\]

第二项：

\[
+\frac12
\sum_k
A_{ik}\gamma_k
\]

由于：

\[
A_{ji}=-A_{ij}
\]

因此两项相同：

\[
\boxed{
\dot\gamma_i
=
\sum_jA_{ij}\gamma_j
}
\tag{8}
\]

写成矩阵形式：

\[
\boxed{
\dot\Gamma
=
A(t)\Gamma
}
\tag{9}
\]

---

# 五、SO(2N) Evolution

定义正交演化矩阵：

\[
\Gamma(t)=R(t)\Gamma(0)
\tag{10}
\]

代入：

\[
\dot R=A(t)R
tag{11}
\]

因此：

\[
\boxed{
R(T)
=
\mathcal P
\exp
\left(
\int_0^TA(t)dt
\right)
}
\tag{12}
\]

由于：

\[
A^T=-A
\]

因此：

\[
R(T)\in SO(2N)
\tag{13}
\]

---

# 六、Effective Hamiltonian

定义：

\[
R(T)
=
e^{A_{\mathrm{eff}}T}
\tag{14}
\]

于是：

\[
\boxed{
A_{\mathrm{eff}}
=
\frac1T\log R(T)
}
\tag{15}
\]

对应 effective Hamiltonian：

\[
\boxed{
H_{\mathrm{eff}}
=
\frac i4
\Gamma^TA_{\mathrm{eff}}\Gamma
}
\tag{16}
\]

因此：

effective Hamiltonian 的严格定义：

就是：

SO(2N) 演化矩阵的 matrix logarithm。

---

# 七、Magnus Expansion

定义：

\[
R(T)=e^{\Omega(T)}
\tag{17}
\]

于是：

\[
A_{\mathrm{eff}}
=
\frac1T\Omega(T)
\tag{18}
\]

---

# 八、Magnus 一阶

\[
\boxed{
\Omega_1
=
\int_0^TA(t_1)dt_1
}
\tag{19}
\]

---

# 九、Magnus 二阶

\[
\boxed{
\Omega_2
=
\frac12
\int_0^Tdt_1
\int_0^{t_1}dt_2
[A(t_1),A(t_2)]
}
\tag{20}
\]

---

# 十、Magnus 三阶

\[
\boxed{
\Omega_3
=
\frac16
\int dt_1dt_2dt_3
(
[A_1,[A_2,A_3]]
+
[A_3,[A_2,A_1]]
)
}
\tag{21}
\]

其中：

\[
A_i=A(t_i)
\]

---

# 十一、Closure 的严格来源

设：

\[
A(t)
=
\sum_\mu
 a_\mu(t)X_\mu
\tag{22}
\]

其中：

\[
X_\mu\in\mathfrak{so}(2N)
\]

则：

---

## 一阶

\[
\Omega_1
\in
\mathrm{span}\{X_\mu\}
\]

---

## 二阶

\[
\Omega_2
\in
\mathrm{span}\{[X_\mu,X_\nu]\}
\]

---

## 三阶

\[
\Omega_3
\in
\mathrm{span}\{[X,[X,X]]\}
\]

因此：

\[
\boxed{
\Omega(T)
\in
\mathrm{Lie}\{X_\mu\}
}
\tag{23}
\]

---

# 十二、Lie Closure

定义初始 generator 集合：

\[
S_0=\{X_\mu\}
\tag{24}
\]

递归：

\[
S_{n+1}
=
S_n
\cup
[S_n,S_n]
\tag{25}
\]

直到：

\[
S_{n+1}=S_n
\]

于是：

\[
\boxed{
\mathfrak g
=
\mathrm{Lie}\{X_\mu\}
}
\tag{26}
\]

---

# 十三、Closure 的物理意义

closure：

决定：

effective Hamiltonian 能够访问的 dynamical manifold。

即：

\[
A_{\mathrm{eff}}
\in
\mathfrak g
\subseteq
\mathfrak{so}(2N)
\]

---

# 十四、PRB105 严格推导

取：

\[
A_1=\theta_1X_{12}
\]

\[
A_2=\theta_2X_{23}
\]

其中：

\[
(X_{ij})_{ab}
=
\delta_{ia}\delta_{jb}
-
\delta_{ib}\delta_{ja}
\tag{27}
\]

计算 commutator：

\[
[X_{12},X_{23}]
=
X_{13}
\tag{28}
\]

因此：

closure：

\[
\boxed{
\mathfrak g
=
\mathrm{span}
\{
X_{12},X_{23},X_{13}
\}
}
\tag{29}
\]

即：

\[
\boxed{
\mathfrak g\simeq\mathfrak{su}(2)
}
\tag{30}
\]

---

# 十五、PRB105 的 Effective Hamiltonian

由于：

closure 只有三维。

因此：

\[
\Omega
=
\alpha X_{12}
+
\beta X_{23}
+
\gamma X_{13}
\tag{31}
\]

于是：

\[
R(T)=e^\Omega
\in SO(3)
\]

利用 Rodrigues 公式：

\[
\boxed{
e^\Omega
=
I
+
\frac{\sin\omega}{\omega}\Omega
+
\frac{1-\cos\omega}{\omega^2}\Omega^2
}
\tag{32}
\]

其中：

\[
\omega^2
=
\alpha^2+\beta^2+\gamma^2
\]

因此：

\[
\boxed{
A_{\mathrm{eff}}
=
\frac1T\Omega
}
\tag{33}
\]

严格得到 effective Hamiltonian。

---

# 十六、Perturbation

设：

\[
A(t)
=
A_0(t)
+
\epsilon B(t)
\tag{34}
\]

其中：

\[
B(t)\in\mathfrak{so}(2N)
\]

新的 closure：

\[
\boxed{
\mathfrak g
=
\mathrm{Lie}
(
\mathfrak g_0
\cup
\{B\}
)
}
\tag{35}
\]

---

# 十七、Closure 不变条件

若：

\[
[B,\mathfrak g_0]
\subseteq
\mathfrak g_0
\tag{36}
\]

则：

不产生新 generator。

因此：

\[
\boxed{
\mathfrak g=\mathfrak g_0
}
\tag{37}
\]

---

# 十八、Closure Enlargement 条件

若：

\[
[B,\mathfrak g_0]
\not\subseteq
\mathfrak g_0
\tag{38}
\]

则：

commutator 会生成新的 generator。

于是：

\[
\boxed{
\mathfrak g>\mathfrak g_0
}
\tag{39}
\]

---

# 十九、最终统一结构

对于任意：

\[
2N
\]

个 Majorana：

---

## Hamiltonian

\[
H(t)
=
\frac i4
\Gamma^TA(t)\Gamma
\]

---

## Dynamics

\[
\dot\Gamma=A(t)\Gamma
\]

---

## Evolution

\[
R(T)
=
\mathcal P
e^{\int A dt}
\in SO(2N)
\]

---

## Effective Hamiltonian

\[
A_{\mathrm{eff}}
=
\frac1T\log R(T)
\]

---

## Lie Closure

\[
\mathfrak g
=
\mathrm{Lie}\{A(t)\}
\]

---

## Magnus Hierarchy

自动生成：

\[
[X,Y],
[X,[Y,Z]],
\dots
\]

---

## Perturbation

决定：

closure 是否扩张。

---

# 二十、最终核心观点

Majorana dynamics 的本质：

不是 Bloch sphere。

不是 quaternion。

不是预设 SU(2)。

真正普适的结构是：

\[
\boxed{
\mathfrak g
=
\mathrm{Lie}\{A(t)\}
\subseteq
\mathfrak{so}(2N)
}
\]

以及：

\[
\boxed{
A_{\mathrm{eff}}
=
\frac1T
\log
\left(
\mathcal P
e^{\int A dt}
\right)
}
\]

即：

Hamiltonian closure 所定义的 dynamical transport geometry。