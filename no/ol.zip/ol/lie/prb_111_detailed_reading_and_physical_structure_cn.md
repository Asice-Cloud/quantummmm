# PRB111 论文详细解读

## Phys. Rev. B 111, 205411

## Quantifying the non-Abelian property of Majorana and Andreev bound states in nanowires

---

# 一、论文真正的核心目标

这篇论文真正研究的问题并不是：

- MZM 是否拓扑
- 拓扑不变量是什么
- Majorana 是否存在

而是：

\[
\boxed{
\text{ABS 是否也能表现出类似 MZM 的非阿贝尔编织性质？}
}
\]

因此，论文真正的研究对象是：

---

# braiding fidelity

而不是：

- Pfaffian
- Chern number
- bulk-boundary correspondence

这是全文最重要的定位。

---

# 二、论文的层次结构

论文实际上包含三层：

---

## Layer 1：微观 BdG 纳米线模型

---

## Layer 2：时间依赖 braiding 数值模拟

---

## Layer 3：低能 effective oscillation fitting

---

很多概念混淆，都是因为这三层没有被明确区分。

---

# 三、微观 BdG Hamiltonian

论文真正的基础模型：

\[
H_{\mathrm{BdG}}
=
\left(
-\frac{\hbar^2\partial_x^2}{2m}
-\mu(x)
\right)\tau_z
+
V_z\sigma_x
+
i\alpha\partial_x\sigma_y\tau_z
+
\Delta(x)\tau_x
\]

其中：

---

## \(\mu(x)\)

化学势。

---

## \(V_z\)

Zeeman 场。

---

## \(\alpha\)

spin-orbit coupling。

---

## \(\Delta(x)\)

超导 pairing。

---

这个 Hamiltonian 才是全文真正的 microscopic starting point。

---

# 四、论文真正引入的新东西

论文真正重要的地方：

并不是 topological nanowire 本身。

而是：

\[
\boxed{
\text{spatial inhomogeneity}
}
\]

包括：

- smooth confinement
- disorder
- interface potential
- quantum dot
- nonuniform electrostatic profile

其目标：

\[
\boxed{
\text{人为制造 near-zero ABS}
}
\]

---

# 五、Figure 1：全文最重要的物理图

Figure 1 的真正意义：

不是展示谱。

而是：

\[
\boxed{
\text{ABS 如何变得像 MZM}
}
\]

论文发现：

一个 ABS：

\[
d=\frac{\gamma_1+i\gamma_2}{\sqrt2}
\]

内部的两个 Majorana component：

\[
\gamma_1,\gamma_2
\]

可以空间分离。

于是：

ABS 会变成：

---

# quasi-Majorana state

---

即：

不是真正拓扑 MZM。

但：

其局域行为类似 MZM。

---

# 六、local estimator η

论文定义：

\[
\eta
=
\sqrt{
\frac{|u_2(L)|}{|u_1(L)|}
}
\]

用于量化：

\[
\boxed{
\text{ABS 的 quasi-Majorana 程度}
}
\]

即：

两个 Majorana component 是否空间分离。

---

# 七、Figure 2-4：ABS engineering

这部分论文在系统研究：

---

# 哪些势场会产生 quasi-MZM

---

包括：

- smooth potential
- quantum dot
- disorder-induced localization
- interface engineering

论文发现：

不同机制都能产生：

\[
E\approx0
\]

的 near-zero ABS。

并且：

这些 ABS：

都可能表现出：

- quantized zero-bias peak
- Majorana-like localization
- non-Abelian-like response

---

# 八、真正核心：braiding simulation

论文真正关键部分：

从 Figure 5 开始。

这里论文开始：

---

# time-dependent braiding simulation

---

这是全文最关键的变化。

因为：

这里已经不是 static Hamiltonian。

而是：

\[
i\partial_t|\psi(t)\rangle
=
H_{\mathrm{BdG}}(t)|\psi(t)\rangle
\]

即：

---

# microscopic dynamical evolution

---

coupling 会随着 braid protocol：

不断打开/关闭。

因此：

Hamiltonian generator 本身不断变化。

---

# 九、论文真正的 braid protocol

论文模拟的是：

T-junction nanowire braid。

不同步骤中：

不同 tunnel coupling：

被 adiabatically 打开/关闭。

因此：

不同时间：

Hamiltonian 的 generator：

不同。

即：

\[
H(t_1)
\neq
H(t_2)
\]

而不是简单比例关系。

---

# 十、braiding fidelity 的定义

论文定义：

\[
F(\tau)
=
|\langle\psi^-_1(6\tau)|\psi^+_1(0)\rangle|
\]

其中：

---

## \(\psi_1^+(0)\)

初始 positive-energy state。

---

## \(\psi_1^-(6\tau)\)

完成 braid 后的 negative-energy partner。

---

理想 MZM braid：

要求：

\[
\psi^+\to\psi^-
\]

因此：

\[
F=1
\]

---

# 十一、论文最重要发现

对于：

- finite-overlap MZM
- ABS
- quasi-MZM

论文发现：

\[
\boxed{
F(\tau)
\text{ 出现 oscillation}
}
\]

包括：

- collapse
- revival
- beating

这才是全文真正核心。

---

# 十二、论文自己的解释

论文使用 effective picture：

定义：

---

## finite overlap

\[
E_1
\]

---

## braid-induced coupling

\[
t_1
\]

---

并认为：

系统在 braid 过程中：

会积累 dynamical phase。

于是：

长时间 braid：

偏离理想 non-Abelian swapping。

---

# 十三、effective oscillation model

论文最后实际上使用：

\[
H_{\mathrm eff}
=
E_1L_{12}
+
t_1L_{23}
\]

来 phenomenologically 拟合 oscillation。

其中：

\[
L_{ij}=\frac i2\gamma_i\gamma_j
\]

这个模型：

closure：

\[
[L_{12},L_{23}]
=2iL_{13}
\]

因此：

\[
\mathfrak g
\simeq
\mathfrak{su}(2)
\]

---

# 十四、解析 oscillation frequency

effective Hamiltonian：

\[
H_{\mathrm eff}
=
E_1L_{12}
+
t_1L_{23}
\]

对应矩阵：

\[
A
=
\begin{pmatrix}
0&E_1&0\\
-E_1&0&t_1\\
0&-t_1&0
\end{pmatrix}
\]

其特征值：

\[
\lambda_\pm
=\pm i\omega
\]

其中：

\[
\boxed{
\omega
=
\sqrt{E_1^2+t_1^2}
}
\]

因此：

fidelity：

\[
F(t)
\sim
\cos^2(\omega t)
\]

这就是论文中的 oscillation 来源。

---

# 十五、Figure 8：全文真正最核心结论

Figure 8 比较：

- true topological MZM
- quasi-MZM ABS

结果非常反直觉：

\[
\boxed{
\text{quasi-MZM 反而更稳定}
}
\]

原因：

quasi-MZM parameter region 中：

\[
E_1\approx0
\]

并且 fluctuation 更小。

因此：

\[
\omega
=
\sqrt{E_1^2+t_1^2}
\]

变化更慢。

于是：

fidelity oscillation period 更长。

因此：

有限时间 braid 中：

反而更接近理想 non-Abelian braid。

---

# 十六、Appendix B：Conductance

Appendix B 使用：

NEGF formalism。

定义：

\[
G^r(\omega)
=
(\omega I-H-\Sigma)^{-1}
\]

以及：

\[
T(\omega)
=
\mathrm{Tr}
[\Gamma G^r\Gamma G^a]
\]

其作用：

只是验证：

---

# near-zero ABS

是否也能产生：

---

# quantized ZBP

---

即：

实验可观测性。

---

# 十七、论文真正的层次结构

现在可以明确：

---

## Layer 1

microscopic BdG dynamics。

---

## Layer 2

low-energy near-zero-mode reduction。

---

## Layer 3

effective oscillation fitting。

---

因此：

论文中的：

\[
E_1,t_1
\]

并不是 microscopic Hamiltonian。

而是：

---

# projected effective parameters。

---

# 十八、论文真正没有做的事情

论文没有使用：

- Lie algebra
- SO(2N)
- Magnus expansion
- closure theory
- dynamic algebra transport
- generator hierarchy

因此：

论文实际上并未回答：

---

# microscopic Hamiltonian

如何决定：

# effective braid algebra。

---

# 十九、论文真正的不足

论文能够解释：

- oscillation
- finite overlap
- dynamical phase accumulation

但：

无法严格区分：

---

## 哪些 perturbation

只 renormalize oscillation frequency；

---

## 哪些 perturbation

真正改变 braid algebra。

---

# 二十、我们模型真正补上的东西

我们现在的 SO(2N)+Magnus+closure 框架：

真正补上的：

\[
\boxed{
\text{从 microscopic BdG}
\rightarrow
\text{effective braid algebra}
}
\]

之间的严格结构。

包括：

- dynamic closure
- Magnus hierarchy
- effective generator growth
- low-energy projection
- braid-sector competition
- algebra stability criterion

这部分：

是 PRB111 原文中没有系统建立的。

