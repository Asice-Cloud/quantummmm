# Dynamic Closure Model for General Time-Dependent \(2N\)-Majorana Systems

---

# 1. Majorana System

Define \(2N\) Majorana operators

\[
\Gamma=(\gamma_1,\gamma_2,\dots,\gamma_{2N})
\]

satisfying

\[
\{\gamma_i,\gamma_j\}=2\delta_{ij}
\]

for

\[
1\le i,j\le 2N.
\]

---

# 2. Clifford Algebra and Quadratic Generators

Define quadratic Majorana bilinears

\[
L_{ij}=\frac{i}{2}\gamma_i\gamma_j
\]

with

\[
L_{ij}=-L_{ji}.
\]

The generators satisfy

\[
[L_{ij},L_{kl}]
=
2i(
\delta_{jk}L_{il}
-\delta_{ik}L_{jl}
-\delta_{jl}L_{ik}
+\delta_{il}L_{jk}
).
\]

Therefore

\[
\boxed{
\mathrm{span}\{L_{ij}\}
\simeq
\mathfrak{so}(2N)
}
\]

with

\[
\dim\mathfrak{so}(2N)=N(2N-1).
\]

---

# 3. General Time-Dependent Quadratic Hamiltonian

The most general quadratic Majorana Hamiltonian is

\[
\boxed{
H(t)=\sum_{i<j}A_{ij}(t)L_{ij}
}
\]

where

\[
A_{ij}(t)=-A_{ji}(t).
\]

Equivalently,

\[
A(t)\in\mathfrak{so}(2N).
\]

---

# 4. Active Generator Set

Define the active generator set

\[
\boxed{
S(t)=\{L_{ij}\mid A_{ij}(t)\neq0\}
}
\]

which determines the instantaneous interaction graph.

---

# 5. Interaction Graph

Define the graph

\[
G(t)=(V,E(t))
\]

with

\[
V=\{1,2,\dots,2N\}
\]

and edge set

\[
(i,j)\in E(t)
\iff
A_{ij}(t)\neq0.
\]

---

# 6. Instantaneous Closure Algebra

Define the instantaneous Lie closure

\[
\boxed{
\mathfrak g_{\mathrm{inst}}(t)
=
\mathrm{Lie}(S(t))
}
\]

which is the smallest Lie algebra containing all active generators.

Recursively,

\[
\mathfrak g_0(t)=\mathrm{span}(S(t))
\]

\[
\mathfrak g_{n+1}(t)
=
\mathfrak g_n(t)
+
[\mathfrak g_n(t),\mathfrak g_n(t)]
\]

until stabilization.

---

# 7. Closure Theorem

Let

\[
G(t)=\bigcup_\alpha G_\alpha(t)
\]

be the decomposition into connected components.

Suppose

\[
|G_\alpha(t)|=2N_\alpha.
\]

Then

\[
\boxed{
\mathfrak g_{\mathrm{inst}}(t)
=
\bigoplus_\alpha
\mathfrak{so}(2N_\alpha)
}
\]

Proof:

Using

\[
[L_{ij},L_{jk}]=2iL_{ik}
\]

all generators within the same connected component are generated recursively.

Disconnected components commute.

---

# 8. Time-Dependent Perturbation

Consider

\[
H(t)=H_0(t)+V(t)
\]

where

\[
H_0(t)\in\mathfrak g_0
\]

and

\[
V(t)=\sum_{i<j}v_{ij}(t)L_{ij}.
\]

Then the interaction graph changes dynamically.

---

# 9. Dynamical Closure Algebra

The instantaneous algebra is insufficient because time ordering generates new directions.

Define the accumulated generator set

\[
\boxed{
\mathcal S(t)
=
\bigcup_{0\le s\le t}S(s)
}
\]

Define the dynamical closure algebra

\[
\boxed{
\mathfrak G(t)
=
\mathrm{Lie}(\mathcal S(t))
}
\]

Equivalently,

\[
\mathfrak G_0(t)
=
\mathrm{span}(\mathcal S(t))
\]

\[
\mathfrak G_{n+1}(t)
=
\mathfrak G_n(t)
+
[\mathfrak G_n(t),\mathfrak G_n(t)]
\]

until closure.

---

# 10. Evolution Equation

The unitary evolution satisfies

\[
\boxed{
\frac{dU(t)}{dt}
=
-iH(t)U(t)
}
\]

with

\[
U(0)=I.
\]

The formal solution is

\[
\boxed{
U(t)
=
\mathcal P
\exp
\left(
-i\int_0^tH(s)ds
\right)
}
\]

where

\[
\mathcal P
\]

denotes time ordering.

---

# 11. Reachable Group Structure

The dynamical closure algebra determines the reachable Lie group.

Define

\[
\boxed{
G_{\mathrm{dyn}}(t)
=
\exp(\mathfrak G(t))
}
\]

The physical unitary acts in the spin representation

\[
\boxed{
U(t)\in\mathrm{Spin}(\mathfrak G(t))
}
\]

with

\[
\mathrm{Spin}(2N)
\rightarrow
SO(2N)
\]

the double covering map.

---

# 12. Majorana Evolution

For

\[
H(t)=\frac{i}{2}\Gamma^TA(t)\Gamma
\]

with

\[
A(t)=-A^T(t),
\]

Majorana operators evolve as

\[
\boxed{
\Gamma(t)
=
R(t)\Gamma(0)
}
\]

where

\[
R(t)\in SO(2N)
\]

satisfies

\[
\boxed{
\frac{dR(t)}{dt}=2A(t)R(t)
}
\]

with

\[
R(0)=I.
\]

Hence

\[
\boxed{
R(t)
=
\mathcal P
\exp
left(
2\int_0^tA(s)ds
\right)
}
\]

and

\[
U^{-1}(t)\gamma_iU(t)
=
\sum_jR_{ij}(t)\gamma_j.
\]

---

# 13. Magnus Expansion

Define

\[
U(t)=e^{\Omega(t)}.
\]

Then

\[
\Omega(t)=\sum_{n=1}^\infty\Omega_n(t).
\]

---

## First Order

\[
\boxed{
\Omega_1(t)
=
-i\int_0^tH(s)ds
}
\]

---

## Second Order

\[
\boxed{
\Omega_2(t)
=
-\frac12
\int_0^tds_1
\int_0^{s_1}ds_2
[H(s_1),H(s_2)]
}
\]

---

## Third Order

\[
\boxed{
\Omega_3(t)
=
\frac{i}{6}
\int_0^tds_1
\int_0^{s_1}ds_2
\int_0^{s_2}ds_3
\Big(
[H_1,[H_2,H_3]]
+
[H_3,[H_2,H_1]]
\Big)
}
\]

where

\[
H_k=H(s_k).
\]

---

# 14. Dynamical Closure Growth

Even if

\[
H(t_1),H(t_2)
\in
\mathfrak g_{\mathrm{inst}},
\]

commutators may generate new directions:

\[
[H(t_1),H(t_2)]
\notin
\mathfrak g_{\mathrm{inst}}.
\]

Therefore

\[
\boxed{
\Omega_n(t)
\in
\mathfrak G(t)
}
\]

and the effective algebra enlarges dynamically.

---

# 15. Perturbation Classification

Let

\[
\mathfrak g_0
\subset
\mathfrak{so}(2N)
\]

be the initial closure.

Add perturbation

\[
V(t)=\sum v_{ij}(t)L_{ij}.
\]

---

## Case A

If

\[
V(t)\in\mathfrak g_0
\]

for all time,

\[
\boxed{
\mathfrak G(t)=\mathfrak g_0
}
\]

and the reachable group remains unchanged.

---

## Case B

If

\[
V(t)\notin\mathfrak g_0
\]

but only finite extensions appear,

\[
\boxed{
\mathfrak G(t)
=
\mathfrak g_0\rtimes\mathfrak k
}
\]

for some extension algebra

\[
\mathfrak k.
\]

---

## Case C

If the perturbation connects disconnected graph sectors,

\[
\boxed{
\mathfrak G(t)
\rightarrow
\mathfrak{so}(2N)
}
\]

for generic connected interaction graphs.

---

# 16. Final Unified Structure

The complete dynamical system is

\[
\boxed{
(\Gamma,H(t),\mathfrak G(t),G_{\mathrm{dyn}}(t),U(t))
}
\]

with

\[
\Gamma=(\gamma_1,\dots,\gamma_{2N})
\]

\[
H(t)=\sum A_{ij}(t)L_{ij}
\]

\[
\mathfrak G(t)
=
\mathrm{Lie}
\left(
\bigcup_{0\le s\le t}S(s)
\right)
\]

\[
G_{\mathrm{dyn}}(t)=\exp(\mathfrak G(t))
\]

\[
U(t)\in\mathrm{Spin}(\mathfrak G(t))
\]

satisfying

\[
\dot U(t)=-iH(t)U(t).
\]

