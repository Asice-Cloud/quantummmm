#!/usr/bin/env python3
import numpy as np
from scipy.linalg import norm

def M(i, j, dim=6):
    A = np.zeros((dim, dim), dtype=float)
    A[i-1, j-1] = 1.0
    A[j-1, i-1] = -1.0
    return A

def build_A(t, params):
    # params: dict with keys 'delta_funcs' (dict idx->func(t)), 'd_func'
    dim = params.get('dim', 6)
    A = np.zeros((dim, dim), dtype=float)
    for k, f in params['delta_funcs'].items():
        val = f(t)
        if abs(val) > 0:
            A += val * M(6, k, dim)
    dval = params['d_func'](t)
    if abs(dval) > 0:
        A += dval * M(1, 2, dim)
    return A

def mat_to_vec(A):
    dim = A.shape[0]
    v = []
    for p in range(dim):
        for q in range(p+1, dim):
            v.append(A[p, q])
    return np.array(v)

def magnus_O1O2(A_ts, tgrid):
    # A_ts: list of A at times tgrid
    n = len(tgrid)
    dt = np.diff(tgrid)
    # Omega1 via trapezoid
    Omega1 = np.zeros_like(A_ts[0])
    for i in range(n-1):
        Omega1 += 0.5 * (A_ts[i] + A_ts[i+1]) * dt[i]
    # Omega2 double integral approx: 1/2 sum_{i>j} [A_i, A_j] dt_i dt_j
    Omega2 = np.zeros_like(A_ts[0])
    for i in range(1, n):
        for j in range(0, i):
            # use dt_i = tgrid[i+1]-tgrid[i] approx: use dt[j] for j index; simpler use midpoint dt = (t[i]-t[i-1]) etc
            # we'll take small uniform dt for simplicity
            # approximate area element: (t[i]-t[i-1])*(t[j+1]-t[j]) but for safety use min adjacent dt
            dti = dt[i-1] if i-1 < len(dt) else dt[-1]
            dtj = dt[j] if j < len(dt) else dt[-1]
            Omega2 += 0.5 * (A_ts[i].dot(A_ts[j]) - A_ts[j].dot(A_ts[i])) * dti * dtj
    return Omega1, Omega2

def project_onto_span(X, basis_mats):
    V = np.column_stack([mat_to_vec(B) for B in basis_mats])
    vx = mat_to_vec(X)
    coeffs, residuals, rank, s = np.linalg.lstsq(V, vx, rcond=None)
    proj = V.dot(coeffs)
    orth = vx - proj
    return np.linalg.norm(proj), np.linalg.norm(orth), coeffs

def make_pulse(center, width, amp):
    return lambda t: amp * np.exp(-0.5 * ((t-center)/width)**2)

def run_sequence(params, T=3.0, N=400):
    tgrid = np.linspace(0, T, N)
    A_ts = [build_A(t, params) for t in tgrid]
    O1, O2 = magnus_O1O2(A_ts, tgrid)
    # define initial generator span (the time-dependent active generators at t=0)
    # use generators present in params: keys of delta_funcs and M12
    basis = []
    for k in params['delta_funcs'].keys():
        basis.append(M(6, k, params.get('dim',6)))
    # also include M12 if relevant
    # include M12 even if d_func initially zero to allow projection
    basis.append(M(1,2, params.get('dim',6)))
    proj_norm, orth_norm, coeffs = project_onto_span(O2, basis)
    print(f"T={T}, N={N}: ||Omega1||={norm(O1):.4e}, ||Omega2||={norm(O2):.4e}")
    print(f"Omega2 projection norm={proj_norm:.4e}, orthogonal norm={orth_norm:.4e}, orth/total={orth_norm/(norm(O2)+1e-16):.3e}")
    return O1, O2, proj_norm, orth_norm

def main():
    # Example A: weak separated pulses (adiabatic)
    paramsA = {
        'dim': 6,
        'delta_funcs': {
            2: make_pulse(0.5, 0.1, 0.1),
            3: make_pulse(1.5, 0.1, 0.1),
            5: make_pulse(2.5, 0.1, 0.1),
        },
        'd_func': lambda t: 0.0,
    }
    print('\n--- Scenario A: weak separated pulses ---')
    run_sequence(paramsA, T=3.0, N=600)

    # Example B: stronger overlapping pulses
    paramsB = {
        'dim': 6,
        'delta_funcs': {
            2: make_pulse(0.9, 0.5, 0.6),
            3: make_pulse(1.5, 0.6, 0.6),
            5: make_pulse(1.1, 0.5, 0.5),
        },
        'd_func': lambda t: 0.05 * np.sin(2*np.pi*t/3.0),
    }
    print('\n--- Scenario B: stronger overlapping pulses ---')
    run_sequence(paramsB, T=3.0, N=600)

if __name__ == '__main__':
    main()
