#!/usr/bin/env python3
import numpy as np
from scipy.linalg import expm, norm

def M(i, j, dim=6):
    A = np.zeros((dim, dim), dtype=float)
    A[i-1, j-1] = 1.0
    A[j-1, i-1] = -1.0
    return A

def gi_profile(t, Tseg):
    # six steps, each of duration Tseg; initial (g1,g2,g3,g4)=(0,0,1,1)
    step = int(np.floor(t / Tseg))
    frac = (t % Tseg) / Tseg
    # helper to linear ramp from a->b across step
    def ramp(a, b, f):
        return a + (b - a) * f
    # define pattern per step (0..5): values at start of step
    patterns = [ (0,0,1,1), (1,0,0,1), (0,1,0,1), (0,0,1,1), (1,0,0,1), (0,1,0,1) ]
    # Next values (start of next step) for linear interpolation
    nextp = patterns[(step+1) % len(patterns)]
    curp = patterns[step % len(patterns)]
    g = tuple(ramp(curp[i], nextp[i], frac) for i in range(4))
    return g

def d_profile(t, Tseg, d0=0.02):
    # hybridization present in sections 1,3,5 (centered at Tseg/2 of each segment index 0,2,4)
    centers = [0.5*Tseg, 2.5*Tseg, 4.5*Tseg]
    width = 0.4 * Tseg
    val = 0.0
    for c in centers:
        val += d0 * np.exp(-0.5 * ((t - c)/width)**2)
    return val

def build_A_from_gi_d(g1,g2,g3,g4, tc, dval, dim=6):
    # δ = tc*(g1*g4, g2*g4, g3*g4) coupling to gamma6 with gamma2,3,5
    A = np.zeros((dim, dim), dtype=float)
    delta1 = tc * (g1 * g4)
    delta2 = tc * (g2 * g4)
    delta3 = tc * (g3 * g4)
    # mapping factor: H includes i*h γp γq corresponds to A contribution 4*h*M(p,q)
    factor = 4.0
    if abs(delta1) > 0:
        A += factor * delta1 * M(6, 2, dim)
    if abs(delta2) > 0:
        A += factor * delta2 * M(6, 3, dim)
    if abs(delta3) > 0:
        A += factor * delta3 * M(6, 5, dim)
    if abs(dval) > 0:
        A += factor * dval * M(1, 2, dim)
    return A

def time_ordered_R(A_ts, tgrid):
    R = np.eye(A_ts[0].shape[0])
    for i in range(len(tgrid)-1):
        dt = tgrid[i+1] - tgrid[i]
        R = expm(A_ts[i]*dt).dot(R)
    return R

def magnus_O1O2(A_ts, tgrid):
    n = len(tgrid)
    dt = np.diff(tgrid)
    Omega1 = np.zeros_like(A_ts[0])
    for i in range(n-1):
        Omega1 += 0.5*(A_ts[i]+A_ts[i+1])*dt[i]
    Omega2 = np.zeros_like(Omega1)
    for i in range(1,n):
        for j in range(0,i):
            dti = dt[i-1] if i-1 < len(dt) else dt[-1]
            dtj = dt[j] if j < len(dt) else dt[-1]
            Omega2 += 0.5*(A_ts[i].dot(A_ts[j]) - A_ts[j].dot(A_ts[i])) * dti * dtj
    return Omega1, Omega2

def fermion_mode_vector(R, indices):
    # indices: tuple (p,q) for γp, γq forming fermion (γp + i γq)/2
    p,q = indices
    # basis vectors e_p and e_q are unit vectors in Majorana basis
    ep = R[:, p-1]
    eq = R[:, q-1]
    return 0.5*(ep + 1j*eq)

def overlap(modeA, modeB):
    # inner product between complex mode vectors
    num = np.vdot(modeA, modeB)
    return num

def approx_LDOS(R):
    # approximate LDOS for wires: W1=(γ1,γ2), W2=(γ3,γ4), W3=(γ5,γ6)
    # sum squared magnitudes of final Majorana columns per wire
    probs = {}
    for w, comps in [('W1',(1,2)), ('W2',(3,4)), ('W3',(5,6))]:
        s = 0.0
        for idx in comps:
            col = R[:, idx-1]
            s += np.sum(np.abs(col)**2)
        probs[w] = s
    return probs

def run(Tseg=100.0, tc=0.02, d0=0.02, N=1200):
    total_time = 6.0 * Tseg
    tgrid = np.linspace(0, total_time, N)
    A_ts = []
    for t in tgrid:
        g1,g2,g3,g4 = gi_profile(t, Tseg)
        dval = d_profile(t, Tseg, d0=d0)
        A = build_A_from_gi_d(g1,g2,g3,g4, tc, dval)
        A_ts.append(A)
    R_ref = time_ordered_R(A_ts, tgrid)
    O1, O2 = magnus_O1O2(A_ts, tgrid)
    R_mag = expm(O1 + O2)

    # compute fermion mode overlaps for ψ1- etc. initial modes on identity
    # initial modes: ψ1- : (γ1 + i γ2)/2 ; ψ1+ : (γ1 - i γ2)/2 ; ψ2- : (γ3 + i γ4)/2 ; ψ2+ : (γ3 - i γ4)/2
    psi1m_init = 0.5*(np.eye(6)[:,0] + 1j*np.eye(6)[:,1])
    psi1p_init = 0.5*(np.eye(6)[:,0] - 1j*np.eye(6)[:,1])
    psi2m_init = 0.5*(np.eye(6)[:,2] + 1j*np.eye(6)[:,3])
    psi2p_init = 0.5*(np.eye(6)[:,2] - 1j*np.eye(6)[:,3])

    psi1m_final = fermion_mode_vector(R_ref, (1,2))
    psi1p_final = fermion_mode_vector(R_ref, (1,2)) * 0.0  # placeholder if needed

    # compute overlaps with initial bases
    o_1m_1p = overlap(psi1m_final, psi1p_init)
    o_1m_1m = overlap(psi1m_final, psi1m_init)
    o_1m_2m = overlap(psi1m_final, psi2m_init)
    # LDOS approx
    ldos = approx_LDOS(R_ref)

    print(f"Total time {total_time}, tc={tc}, d0={d0}")
    print(f"||Omega1||={norm(O1):.4e}, ||Omega2||={norm(O2):.4e}")
    print('Overlaps for psi1- final:')
    print(f"<psi1- (final) | psi1- (init)> = {o_1m_1m:.6f}")
    print(f"<psi1- (final) | psi1+ (init)> = {o_1m_1p:.6f}")
    print(f"<psi1- (final) | psi2- (init)> = {o_1m_2m:.6f}")
    print('Approx LDOS per wire (sum squares):', ldos)
    # return data
    return {
        'tgrid': tgrid,
        'A_ts': A_ts,
        'R_ref': R_ref,
        'R_mag': R_mag,
        'O1': O1,
        'O2': O2,
    }

if __name__ == '__main__':
    run()
