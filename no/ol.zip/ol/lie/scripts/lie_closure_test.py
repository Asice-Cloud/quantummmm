#!/usr/bin/env python3
import numpy as np

def L(i, j, dim):
    """Return antisymmetric generator matrix with +1 at (i,j) and -1 at (j,i).
    Indices i,j are 1-based.
    """
    A = np.zeros((dim, dim), dtype=float)
    A[i-1, j-1] = 1.0
    A[j-1, i-1] = -1.0
    return A

def mat_to_vec(A):
    # encode antisymmetric matrix by upper-triangle (i<j) entries
    dim = A.shape[0]
    vec = []
    for p in range(dim):
        for q in range(p+1, dim):
            vec.append(A[p, q])
    return np.array(vec)

def closure_span(initial_list, tol=1e-8):
    """Compute Lie closure (span under commutators) starting from initial_list of matrices.
    Returns basis_matrices (list) and boolean whether stabilized.
    """
    dim = initial_list[0].shape[0]
    basis = [A.copy() for A in initial_list]
    changed = True
    while changed:
        changed = False
        # compute all commutators
        cur = list(basis)
        for i in range(len(cur)):
            for j in range(i, len(cur)):
                C = cur[i].dot(cur[j]) - cur[j].dot(cur[i])
                # project onto current basis span using vectorization
                vC = mat_to_vec(C)
                if np.linalg.norm(vC) < tol:
                    continue
                M = np.column_stack([mat_to_vec(B) for B in basis])
                # solve least-squares
                coeffs, residuals, rank, s = np.linalg.lstsq(M, vC, rcond=None)
                approx = M.dot(coeffs)
                if np.linalg.norm(vC - approx) > 1e-6:
                    basis.append(C)
                    changed = True
        # loop until no change
    # orthonormalize basis (vectorized) and return
    vecs = np.column_stack([mat_to_vec(B) for B in basis])
    # perform QR to find independent count and independent basis
    Q, R = np.linalg.qr(vecs)
    # pick independent columns by non-negligible diagonal R
    inds = [k for k in range(R.shape[0]) if abs(R[k, k]) > 1e-8]
    independent = [basis[i] for i in inds]
    return independent

def run_example(dim, pairs):
    gens = [L(i, j, dim) for (i, j) in pairs]
    basis = closure_span(gens)
    print(f"dim={dim}, initial pairs={pairs}")
    print(f"initial count = {len(gens)}, closure basis size = {len(basis)}")
    print("Closure basis (upper-triangle nonzero counts):")
    for B in basis:
        v = mat_to_vec(B)
        nz = np.sum(np.abs(v) > 1e-8)
        print(f"  nonzero components: {nz}")
    print("---")

def main():
    # Example 1: dim=4 (2N=4), S0 = {L12, L23} -> expected closure dim 3 (su2)
    run_example(4, [(1,2),(2,3)])

    # Example 2: dim=4, S0 = {L12, L23, L34} -> expected closure dim 6 (so(4))
    run_example(4, [(1,2),(2,3),(3,4)])

    # PRB105 minimal model: use 2N=6 Majoranas, generators from Eq.(3)
    # Heff = i gamma6*(t1 gamma2 + t2 gamma3 + t3 gamma5) + i d(t) gamma1 gamma2
    # initial generator set: L62, L63, L65, L12
    run_example(6, [(6,2),(6,3),(6,5),(1,2)])

if __name__ == '__main__':
    main()
