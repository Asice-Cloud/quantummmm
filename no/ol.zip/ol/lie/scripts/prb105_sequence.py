#!/usr/bin/env python3
import numpy as np
from scipy.linalg import expm

def M(i, j, dim):
    A = np.zeros((dim, dim), dtype=float)
    A[i-1, j-1] = 1.0
    A[j-1, i-1] = -1.0
    return A

def R_hybrid(delta, d, duration, dim=6):
    # delta: dict mapping index -> coupling to gamma6, e.g. {2: t1, 3: t2, 5: t3}
    A = np.zeros((dim, dim), dtype=float)
    for k, val in delta.items():
        A += val * M(6, k, dim)
    if d != 0:
        A += d * M(1, 2, dim)
    return expm(duration * A)

def R_braid(i, j, dim=6):
    # B = exp(pi/4 gamma_i gamma_j) -> single-particle R = exp((pi/2) * M_{ij})
    theta = np.pi/2
    return expm(theta * M(i, j, dim))

def basis_map(R):
    dim = R.shape[0]
    imgs = []
    for i in range(dim):
        v = R[:, i]
        # find largest component
        idx = int(np.argmax(np.abs(v))) + 1
        sign = np.sign(v[idx-1])
        imgs.append((i+1, idx, float(sign), float(v[idx-1])))
    return imgs

def print_map(imgs):
    for src, dst, sgn, val in imgs:
        print(f"gamma{src} -> {sgn:+.0f} * gamma{dst} (main comp {val:.3f})")

def main():
    dim = 6
    # choose representative hybridization pulses (weak)
    # segment durations
    t1 = 0.2
    t2 = 0.2
    t3 = 0.2

    # coupling strengths for delta (to gamma6)
    delta1 = {2: 0.5, 3: 0.0, 5: 0.0}
    delta2 = {2: 0.0, 3: 0.6, 5: 0.0}
    delta3 = {2: 0.0, 3: 0.0, 5: 0.4}

    d1 = 0.3
    d2 = 0.0
    d3 = 0.1

    R1 = R_hybrid(delta1, d1, t1, dim)
    B1 = R_braid(2, 3, dim)
    R2 = R_hybrid(delta2, d2, t2, dim)
    B2 = R_braid(2, 3, dim)
    R3 = R_hybrid(delta3, d3, t3, dim)

    R_total = R3 @ B2 @ R2 @ B1 @ R1

    print("Mapping after sequence (hyb->braid->hyb->braid->hyb):")
    imgs = basis_map(R_total)
    print_map(imgs)

    # Check two consecutive pure braids effect
    B = R_braid(2,3,dim)
    B2pure = B @ B
    print('\nMapping after two pure braids B(2,3)^2:')
    print_map(basis_map(B2pure))

if __name__ == '__main__':
    main()
