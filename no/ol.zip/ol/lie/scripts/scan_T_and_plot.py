#!/usr/bin/env python3
import numpy as np
import os
from importlib import util

# load run() from scripts/run_prb105_repro.py
spec = util.spec_from_file_location("run_prb105_repro", os.path.join(os.path.dirname(__file__), "run_prb105_repro.py"))
mod = util.module_from_spec(spec)
spec.loader.exec_module(mod)
run = mod.run

def compute_overlaps_for_T(T_total, tc=0.02, d0=0.02, N=1200):
    Tseg = float(T_total) / 6.0
    data = run(Tseg=Tseg, tc=tc, d0=d0, N=N)
    R = data['R_ref']
    # initial fermion modes
    psi1m_init = 0.5*(np.eye(6)[:,0] + 1j*np.eye(6)[:,1])
    psi1p_init = 0.5*(np.eye(6)[:,0] - 1j*np.eye(6)[:,1])
    psi2m_init = 0.5*(np.eye(6)[:,2] + 1j*np.eye(6)[:,3])

    psi1m_final = 0.5*(R[:,0] + 1j*R[:,1])

    o_1m_1m = np.vdot(psi1m_final, psi1m_init)
    o_1m_1p = np.vdot(psi1m_final, psi1p_init)
    o_1m_2m = np.vdot(psi1m_final, psi2m_init)
    return {
        'T': T_total,
        'o_1m_1m': o_1m_1m,
        'o_1m_1p': o_1m_1p,
        'o_1m_2m': o_1m_2m,
        'O1_norm': np.linalg.norm(data['O1']),
        'O2_norm': np.linalg.norm(data['O2']),
    }

def main():
    outdir = os.path.join(os.path.dirname(__file__), '..', 'outputs')
    os.makedirs(outdir, exist_ok=True)
    # target coarse points and a finer scan for curve
    coarse = [400.0, 450.0, 500.0]
    fine = np.linspace(360.0, 520.0, 33)
    results = []
    for T in fine:
        print(f"Running T={T:.1f}")
        res = compute_overlaps_for_T(T)
        results.append(res)
    # save numeric data
    np.savez(os.path.join(outdir, 'prb105_Tscan.npz'), results=results)

    try:
        import matplotlib.pyplot as plt
    except Exception:
        print('matplotlib not available; skipping plot generation')
        return

    Ts = [r['T'] for r in results]
    vals = [np.abs(r['o_1m_1m']) for r in results]
    plt.figure(figsize=(6,4))
    plt.plot(Ts, vals, '-o', markersize=4)
    for tc in coarse:
        plt.axvline(tc, color='gray', linestyle='--', alpha=0.6)
    plt.xlabel('Total T (1/Δ units)')
    plt.ylabel('|<ψ1- (6T) | ψ1- (0)>|')
    plt.title('PRB105: overlap vs T (six-step sequence)')
    plt.tight_layout()
    figpath = os.path.join(outdir, 'prb105_Tscan.png')
    plt.savefig(figpath, dpi=200)
    print('Saved plot to', figpath)

if __name__ == '__main__':
    main()
