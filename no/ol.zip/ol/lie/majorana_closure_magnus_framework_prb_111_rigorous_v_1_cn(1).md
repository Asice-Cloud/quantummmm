# Majorana Closure + Magnus Framework

# PRB111 严格分析框架（Rigorous Version）

---

# 一、目标

本文建立一个严格的：

- Majorana closure
- Magnus hierarchy
- Dynamical Lie algebra
- Coupling graph completion
- Holonomy enlargement

统一分析框架。

目标不是：

预设：

- qubit
- Bloch sphere
- SU(2)
- quaternion

而是：

从一般：

\[
2N
\]

个 Majorana 的 quadratic Hamiltonian 出发，

严格研究：

\[
\mathfrak g
=
\mathrm{Lie}\{H(t)\}
\]

以及：

Magnus hierarchy 如何生成 closure enlargement。

---

# 二、Majorana 与 Clifford Algebra

定义 Majorana：

\[
\gamma_i^\dagger=\gamma_i
\]

满足：

\[
\{\gamma_i,\gamma_j\}=2\delta_{ij}
\tag{1}
\]

对于：

\[
2N
\]

个 Majorana：

\[
\gamma_1,\gamma_2,\dots,\gamma_{2N}
\]

它们生成 Clifford algebra：

\[
Cl(2N)
\tag{2}
\]

---

# 三、Quadratic Majorana Hamiltonian

任意 quadratic Majorana Hamiltonian：

\[
\boxed{
H(t)
=
\frac i2
\sum_{ij}
A_{ij}(t)\gamma_i\gamma_j
}
\tag{3}
\]

其中：

\[
A_{ij}=-A_{ji}
\]

定义 generator：

\[
L_{ij}=i\gamma_i\gamma_j
\tag{4}
\]

则：

\[
H(t)=\sum_{i<j}A_{ij}(t)L_{ij}
\tag{5}
\]

---

# 四、SO(2N) Algebra

计算：

\[
[L_{ij},L_{kl}]
\]

利用 Clifford algebra：

\[
\{\gamma_i,\gamma_j\}=2\delta_{ij}
\]

得到：

\[
\boxed{
[L_{ij},L_{kl}]
=
2i(
\delta_{jk}L_{il}
-
\delta_{ik}L_{jl}
-
\delta_{jl}L_{ik}
+
\delta_{il}L_{jk}
)
}
\tag{6}
\]

因此：

\[
\boxed{
\{L_{ij}\}
\text{ closure 于 }
\mathfrak{so}(2N)
}
\tag{7}
\]

重要：

quadratic Majorana Hamiltonian 的 dynamics：

永远不会离开：

\[
\mathfrak{so}(2N)
\]

因此：

PRB111 的复杂性：

不是离开 quadratic sector。

而是：

\[
\boxed{
\mathfrak{so}(2N)
\text{ 内部的 closure enlargement}
}
\]

---

# 五、Dynamical Lie Algebra

给定：

\[
H(t)=\sum_ah_a(t)G_a
\]

其中：

\[
G_a\in\mathfrak{so}(2N)
\]

定义 dynamical Lie algebra：

\[
\boxed{
\mathfrak g
=
\mathrm{Lie}\{H(t)\}
}
\tag{8}
\]

即：

所有 generator 与其 commutator closure 的最小 Lie algebra。

---

# 六、Closure Algorithm

定义：

初始 generator 集合：

\[
S_0=\{G_a\}
\tag{9}
\]

递归：

\[
S_{n+1}
=
S_n
\cup
[S_n,S_n]
\tag{10}
\]

直到：

\[
S_{n+1}=S_n
\]

于是：

\[
\boxed{
\mathfrak g
=
\mathrm{span}(S_\infty)
}
\tag{11}
\]

---

# 七、Closure 的真正物理意义

closure 并不是数学形式。

它真正描述的是：

\[
\boxed{
\text{Dynamics 实际访问的 transport manifold}
}
\]

即：

系统真正的 holonomy geometry。

---

# 八、PRB105：SU(2) Closure

PRB105 中：

最小 generator：

\[
S_0^{(105)}
=
\{L_{12},L_{23}\}
\tag{12}
\]

计算：

\[
[L_{12},L_{23}]
=
2iL_{13}
\tag{13}
\]

于是：

\[
S_1
=
\{L_{12},L_{23},L_{13}\}
\]

继续 closure：

\[
[L_{12},L_{13}]
=-2iL_{23}
\]

\[
[L_{23},L_{13}]
=2iL_{12}
\]

不再生成新 generator。

因此：

\[
\boxed{
\mathfrak g_{105}
\simeq
\mathfrak{su}(2)
}
\tag{14}
\]

因此：

PRB105：

对应：

- Bloch sphere
- Rodrigues formula
- quaternion dynamics

并存在：

\[
U=e^{-i\theta\hat n\cdot J}
\tag{15}
\]

这种 exact closed-form solution。

---

# 九、PRB111：Closure Enlargement

PRB111 的核心不是单 perturbation。

而是：

不同时间阶段访问不同 coupling channels。

因此：

\[
[H(t_1),H(t_2)]\neq0
\]

开始真正重要。

---

# 十、最小 PRB111-Type Model

考虑：

6 个 Majorana：

\[
\Gamma_1,\Gamma_2,\Gamma_3,\Gamma_4,\eta_1,\eta_2
\]

定义：

\[
\chi_a
=
(\Gamma_1,\Gamma_2,\Gamma_3,\Gamma_4,\eta_1,\eta_2)
\]

完整 algebra：

\[
\mathfrak{so}(6)
\]

共有：

\[
15
\]

个 generator。

---

# 十一、PRB111 Coupling Graph

例如：

若 protocol 中访问：

\[
L_{12},L_{23},L_{15},L_{35}
\]

则：

初始集合：

\[
S_0
=
\{L_{12},L_{23},L_{15},L_{35}\}
\tag{16}
\]

---

# 十二、第一轮 Closure

计算：

---

## 1

\[
[L_{12},L_{23}]
=
2iL_{13}
\tag{17}
\]

新增：

\[
L_{13}
\]

---

## 2

\[
[L_{12},L_{15}]
=
2iL_{25}
\tag{18}
\]

新增：

\[
L_{25}
\]

---

## 3

\[
[L_{23},L_{35}]
=
2iL_{25}
\tag{19}
\]

已有。

---

## 4

\[
[L_{15},L_{35}]
=
2iL_{13}
\tag{20}
\]

已有。

---

于是：

\[
S_1
=
\{L_{12},L_{23},L_{13},L_{15},L_{25},L_{35}\}
\tag{21}
\]

---

# 十三、第二轮 Closure

继续：

\[
[L_{25},L_{35}]
=
2iL_{23}
\]

已有。

---

\[
[L_{13},L_{15}]
=-2iL_{35}
\]

已有。

---

\[
[L_{13},L_{35}]
=2iL_{15}
\]

已有。

---

\[
[L_{13},L_{25}]=0
\]

---

\[
[L_{12},L_{35}]=0
\]

---

目前：

尚未生成新 generator。

---

# 十四、关键问题：Closure 是否真正停止？

不能提前下结论。

因为：

closure 是否最终终止：

取决于：

完整 protocol 是否访问更多 couplings。

例如：

若进一步出现：

\[
L_{45}
\]

则：

\[
[L_{35},L_{45}]
=
2iL_{34}
\]

继续：

\[
[L_{23},L_{34}]
=
2iL_{24}
\]

closure 会继续增长。

甚至：

最终生成完整：

\[
\mathfrak{so}(6)
\]

---

# 十五、严格结论

因此：

不能简单说：

\[
\mathfrak g=\mathfrak{so}(4)
\]

已经严格成立。

真正严格成立的是：

---

## PRB105

严格 closure 于：

\[
\mathfrak{su}(2)
\]

---

## PRB111

严格发生：

\[
\boxed{
\text{closure enlargement beyond single }SU(2)
}
\]

---

并且：

Magnus hierarchy 会不断生成新的 transport directions。

---

# 十六、Coupling Graph Interpretation

现在定义：

节点：

\[
\gamma_i
\]

边：

\[
(i,j)
\iff
L_{ij}
\text{ 出现在 Hamiltonian 中}
\]

于是：

Hamiltonian 对应一个 coupling graph。

---

# 十七、Commutator 与 Graph Completion

利用：

\[
[L_{ij},L_{jk}]
\sim
L_{ik}
\tag{22}
\]

得到：

---

# Lie closure

等价于：

---

# graph transitive completion

---

即：

若：

\[
(i,j),(j,k)
\]

存在。

则：

closure 自动生成：

\[
(i,k)
\]

---

# 十八、PRB105 的 Graph Structure

PRB105：

对应：

triangle graph：

\[
1-2-3
\]

closure 自动生成：

\[
1-3
\]

于是形成：

完整 triangle：

\[
K_3
\]

对应：

\[
\mathfrak{su}(2)
\]

---

# 十九、PRB111 的 Graph Structure

PRB111：

对应：

更复杂 coupling graph。

因此：

closure 不再停留于单 triangle。

而开始生成：

更多 independent transport directions。

因此：

不再 quaternion-reducible。

---

# 二十、Magnus Expansion

时间演化：

\[
U(T)
=
\mathcal P
e^{-i\int_0^T H(t)dt}
\tag{23}
\]

定义 Magnus expansion：

\[
U=e^{\Omega(T)}
\tag{24}
\]

---

## 一阶

\[
\Omega_1
=-i\int Hdt
\tag{25}
\]

---

## 二阶

\[
\Omega_2
=-\frac12
\int dt_1dt_2
[H(t_1),H(t_2)]
\tag{26}
\]

---

## 三阶

\[
\Omega_3
\sim
[H,[H,H]]
\tag{27}
\]

---

# 二十一、Magnus Hierarchy 的真正意义

由于：

\[
\Omega_2
\sim
[L_{ij},L_{jk}]
]

因此：

Magnus hierarchy：

实际上就是：

\[
\boxed{
\text{graph-induced Lie closure hierarchy}
}
\]

即：

Magnus expansion 自动探索 dynamical closure。

---

# 二十二、PRB111 的真正物理含义

PRB111 中：

复杂 fidelity oscillation 的来源：

不是：

单一 Bloch rotation mismatch。

而是：

\[
\boxed{
\text{closure enlargement induced transport geometry}
}
\]

即：

Hamiltonian coupling graph 导致的 dynamical manifold enlargement。

---

# 二十三、最终统一理论

整个理论最终统一为：

\[
Cl(2N)
\]

↓

\[
\mathfrak{so}(2N)
\]

↓

Hamiltonian coupling graph

↓

Lie closure

↓

Magnus hierarchy

↓

transport manifold

↓

fidelity geometry

---

# 二十四、最终核心观点

Bloch sphere：

不是 Majorana 的本质。

Quaternion：

不是先验结构。

SU(2)：

不是普适 algebra。

真正普适的是：

\[
\boxed{
H(t)\subseteq\mathfrak{so}(2N)
}
\]

以及：

\[
\boxed{
\mathfrak g
=
\mathrm{Lie}\{H(t)\}
}
\]

即：

Hamiltonian closure 所定义的 dynamical geometry。

---

# 二十五、真正的研究方向

最终真正需要研究的是：

给定：

\[
H(t)=\sum_{ij}A_{ij}(t)L_{ij}
\]

研究：

- coupling graph topology
- closure dimension growth
- Lie algebra classification
- Magnus hierarchy
- holonomy enlargement
- fidelity geometry
- exact-solvable dynamical phases

---

# 二十六、总结

我们最终得到的：

不是：

“Majorana 的 Bloch sphere 理论”。

而是：

\[
\boxed{
\text{SO(2N) Closure + Magnus Theory}
}
\]

即：

一个从 Clifford algebra 出发，

通过：

- Lie closure
- coupling graph completion
- Magnus hierarchy
- transport manifold enlargement

统一描述：

- Majorana braid
- perturbation
- fidelity
- non-Abelian dynamics
- PRB105
- PRB111

的完整理论框架。

