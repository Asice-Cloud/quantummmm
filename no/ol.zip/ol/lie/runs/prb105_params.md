PRB105 parameter extraction and notes

Extracted from `phy/Phy.txt` (Physical Review B 105, 054507 (2022)):

- Superconducting pairing amplitude: Δ = 250 μeV
- Hopping amplitude: t0 = 10 Δ = 2500 μeV
- Rashba coupling UR = 2 Δ = 500 μeV
- Quantum dot potential depth: VD = 0.1 t0 = 250 μeV
- QD half-width: LD = 10 a
- Trivial superconductor center length: Nc = 5 a
- Superconducting phase difference used in examples: φ0 = 0.5 π

- Time units used in paper: many plots use times expressed as multiples of 1/Δ
  e.g. examples at T = 400/Δ, 450/Δ, 500/Δ.

Effective low-energy model (paper Eq.(3)):

  Heff(t) = i γ6 (δ · γ) + i d(t) γ1 γ2

where

  δ = (t1, t2, t3) are effective couplings between γ6 and (γ2,γ3,γ5)
  d(t) is the local ABS internal coupling (controls ABS splitting / fusion)

Items NOT explicitly specified in the paper text file and required for numerical mapping:

- Numerical values/time-dependence of the effective couplings t1(t), t2(t), t3(t).
- Functional form and amplitude of d(t) during each braiding/hybridization step.
- Exact time allocation for each hybridization vs braid substep (paper uses a single-step duration T and examples at multiples of 1/Δ; mapping to pulse timings needs clarification).

Proposed next actions (choose one):

1) I use the extracted physical constants and pick conservative representative effective-model pulses (Gaussian/rectangular) and the paper's example times (T = 400/Δ etc.) to produce a numeric reproduction and report; or
2) You provide the exact effective couplings/time-profiles (if you have them from the supplement or notes) and I use those for exact reproduction.

If you approve (1), I'll proceed to map Heff → A(t) in the so(2N) representation and run Magnus + time-ordered evolution comparisons.
